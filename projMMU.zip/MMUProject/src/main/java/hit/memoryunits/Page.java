package hit.memoryunits;

public class Page<T> extends java.lang.Object{

}
