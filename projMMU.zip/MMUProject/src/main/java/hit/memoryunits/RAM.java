package hit.memoryunits;

public class RAM extends java.lang.Object{

	public RAM(int initialCapacity){};
	

}
